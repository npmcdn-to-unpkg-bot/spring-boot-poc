import {Component} from 'angular2/core';
import {NgForm} from 'angular2/common';
import {Http, HTTP_PROVIDERS} from 'angular2/http';
import 'rxjs/add/operator/map';

@Component({
	selector: 'my-app',
	viewProviders: [HTTP_PROVIDERS],
	templateUrl: 'app/template.html'
})
export class AppComponent{
	msg:string='';
	constructor(http: Http) {
    http.get('http://localhost:8080/demo?Id=1&str=Manas&num=32112&d=1.2D')
    	.map((res) => res.json())
    	.subscribe(msg => this.msg=msg);
}