insert into DEMO_BEAN values(1,1,'a');
insert into DEMO_BEAN values(2,2,'b');