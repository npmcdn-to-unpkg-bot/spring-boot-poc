package sample.jsp;

import java.util.Date;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import sample.jsp.jpa.DemoBeanRepository;

@Controller
public class SampleController
{
			
	@Autowired
	private DemoBeanRepository demoBeanRepository;
	
	@RequestMapping("/test")
	public String index(Map<String, Object> model)
	{
		model.put("time", new Date());
		model.put("demoBeans", demoBeanRepository.findAll());
		return "test";
	}
}
