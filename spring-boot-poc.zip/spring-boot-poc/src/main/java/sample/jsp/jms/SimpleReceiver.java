package sample.jsp.jms;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;
import org.springframework.util.FileSystemUtils;

@Component
public class SimpleReceiver 
{

	@Autowired
	ConfigurableApplicationContext context;

	@JmsListener(destination="test-queue", containerFactory="myJmsContainerFactory")
	public void receiveMessage(String msg)
	{
		System.out.println("Msg received << "+ msg);
		//context.close();
		FileSystemUtils.deleteRecursively(new File("activemq-data"));
	}

}
