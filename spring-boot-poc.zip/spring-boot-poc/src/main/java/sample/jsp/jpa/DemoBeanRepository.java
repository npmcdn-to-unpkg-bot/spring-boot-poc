package sample.jsp.jpa;

import org.springframework.data.repository.CrudRepository;

public interface DemoBeanRepository extends CrudRepository<DemoBean, Long>{

}
