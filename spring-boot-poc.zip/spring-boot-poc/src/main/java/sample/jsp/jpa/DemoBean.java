package sample.jsp.jpa;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class DemoBean 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	long id;
	int a;
	String s;

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public String getS() {
		return s;
	}

	public void setS(String s) {
		this.s = s;
	}

	public long getId() {
		return id;
	}

	DemoBean()
	{}

	DemoBean(int a, String s){
		this.a= a;
		this.s= s;
	}

	@Override
	public String toString()
	{
		return String.format(
				"DemoBean[id=%d, a='%d', s='%s']",
				id, a, s);
	}

}
