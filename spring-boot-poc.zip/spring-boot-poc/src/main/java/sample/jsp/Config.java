package sample.jsp;

import javax.jms.ConnectionFactory;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.h2.server.web.WebServlet;
import org.springframework.boot.context.embedded.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.config.JmsListenerContainerFactory;
import org.springframework.jms.config.SimpleJmsListenerContainerFactory;

@Configuration
public class Config 
{
	private static final String JMS_BROKER_URL = "tcp://PC213712:61616";

	@Bean
	ServletRegistrationBean h2servletRegistration()
	{
		ServletRegistrationBean registrationBean = new ServletRegistrationBean( new WebServlet());
		registrationBean.addUrlMappings("/console/*");
		return registrationBean;
	}

	@Bean
	public ConnectionFactory connectionFactory()
	{
		return new ActiveMQConnectionFactory(JMS_BROKER_URL);
	}

	@Bean // This bean is only necessary when hosting an external JMS broker. Boot creates a default in case of an embedded broker.
	JmsListenerContainerFactory<?> myJmsContainerFactory(ConnectionFactory connectionFactory) {
		SimpleJmsListenerContainerFactory factory = new SimpleJmsListenerContainerFactory();
		factory.setConnectionFactory(connectionFactory);
		return factory;
	}

}